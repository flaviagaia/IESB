library(tidyverse) 

list.files(path = "../input")

wine <- read.table("http://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data", sep = ",")

head(wine, n = 4)

dim(wine)

names(wine)

colnames(wine) <- c('Type', 'Alcohol', 'Malic', 'Ash', 'Alcalinity', 'Magnesium', 'Phenols', 'Flavanoids', 'Nonflavanoids','Proanthocyanins', 'Color', 'Hue', 'Dilution', 'Proline')

names(wine)

str(wine)

wine$Type <- as.factor(wine$Type)

str(wine)

colMeans(wine[, 2:5])

by(wine[2:5], wine$Type, colMeans)

var.wine <- var(wine[2:5])

round(var.wine, 2)

library(corrplot)

cor.wine <- cor(wine[, 2:5])

round(cor.wine, 2)

corrplot(cor.wine, method = "ellipse")

library(lattice)

pairs(wine[,2:5])

splom( ~ wine[,2:5],  pch = 16, col = wine$Type)

library(ggplot2)
library(GGally)

wine.gg <- ggpairs(data = wine, mapping = aes(color = Type), columns = 2:5)
wine.gg

library(mvtnorm)

mu.sim <- c(2, -2, 1)
sigma.sim <- matrix(data = c(9,5,5,5,5,3,5,3,4), nrow = 3)

multnorm.sample <- rmvnorm(n = 100, mean = mu.sim, sigma = sigma.sim)

head(multnorm.sample)

ggpairs(data.frame(multnorm.sample))

library(scatterplot3d)

multnorm.dens <- dmvnorm(multnorm.sample, mean = mu.sim, sigma = sigma.sim)

scatterplot3d(cbind(multnorm.sample, multnorm.dens),    
              color="blue", pch="", type = "h",             
              xlab = "x", ylab = "y", zlab = "density")

pmvnorm(lower = c(-1, -1), upper = c(1, 1))

pmvnorm(lower = c(-5, -5), upper = c(5, 5), mean = mu.sim, sigma = sigma.sim)

qmvnorm(0.9, tail = "both", sigma = diag(2))

qmvnorm(0.95, tail = "both", mean = mu.sim, sigma = sigma.sim)

qqnorm(multnorm.sample[, 1])
qqline(multnorm.sample[, 1])

library(MVN)

help("mvn")

wine.mvntest <- mvn(data = wine[, 2:5], mvnTest = "mardia",  multivariatePlot = "qq")

wine.mvntest

mvn(multnorm.sample)

hzTest <- mvn(data = wine[, 2:5], mvnTest = "hz")

hzTest

multt.sample <- rmvt(n = 200,sigma = sigma.sim, df = 5, delta = mu.sim)

head(multt.sample)

mardiaTest <- mvn(multt.sample, mvnTest = "mardia",  multivariatePlot = "qq")

mardiaTest

multt.dens <- dmvt(x = multt.sample, delta = mu.sim, sigma = sigma.sim, df = 5)

pmvt(lower = c(-5, -5), upper = c(5, 5), delta = mu.sim, df = 5, sigma = sigma.sim)

qmvt(p = 0.9, tail = "both", sigma = diag(2))

install.packages("stats4")

library(stats4)

library(sn)

skewnorm.sample <- rmsn(n = 100, xi = mu.sim, Omega = sigma.sim, alpha = c(4, -4))

head(skewnorm.sample)

skewt.sample <- rmst(n = 100, xi = mu.sim, Omega = sigma.sim, alpha = c(4, -4), nu = 5)

head(skewt.sample)

skewt.Test <- mvn(skewt.sample, mvnTest = "mardia",  multivariatePlot = "qq")

pca.state <- princomp(state.x77, cor = TRUE, scores = TRUE) 

plot(pca.state) 

summary(pca.state) 

pca.var <- pca.state$sdev^2

pca.pvar <- pca.var/sum(pca.var)

pca.pvar

plot(cumsum(pca.pvar), xlab = "Principal component", ylab = "Cumulative Proportion of variance explained", ylim = c(0,1), type = 'b')
grid()

abline(h = 0.95, col = "blue")

screeplot(pca.state, type = "l")
grid()

scores.state <- data.frame(pca.state$scores)

ggplot(data = scores.state, aes(x = Comp.1, y = Comp.2, label = rownames(scores.state), color = state.region)) + 
  geom_text(alpha = 0.8, size = 3) + 
  ggtitle("PCA of states data colored by region")

install.packages(c("FactoMineR", "factoextra"))

library("FactoMineR")
library("factoextra")

fviz_pca_ind(pca.state)

fviz_pca_var(pca.state)

fviz_pca_biplot(pca.state)

state.dist <- dist(state.x77)

mds.state <- cmdscale(state.dist) 

mds.state_df <- data.frame(mds.state)

ggplot(data = mds.state_df, aes(x = X1, y = X2, label = rownames(mds.state), color = state.region)) + 
  geom_text(alpha = 0.8, size = 3)  

wine.dist <- dist(wine[,-1])

mds.wine <- cmdscale(wine.dist, k = 3) 
mds.wine_df <- data.frame(mds.wine)

scatterplot3d(mds.wine_df, color = wine$Type, pch = 19, type = "h", lty.hplot = 2)